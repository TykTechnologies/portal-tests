export function SelectMultiple({slectorId, tagsWrapperId, allValue}) {
  let selector = document.getElementById(slectorId);
  let tagsWrapper = document.getElementById(tagsWrapperId);
  let tagsWrapperChildren = document.getElementById(tagsWrapperId)?.children;
  let allowedValues = [allValue];
  let defaultNode = tagsWrapperChildren?.item(0)
  const init = () => {
    selector?.addEventListener('change', (e) => {
      let value = e.target.value;
      if (allowedValues < 1 || value != allValue) {
        if (!allowedValues.includes(value) && !allowedValues.includes(allValue)) {
          selector.value = '';
          const item = document.createElement('div');
          item.classList.add('tag-item');
          item.innerHTML = `${value}
          <i class="bi bi-x x-icon"></i>`;
          item.addEventListener('click', () => {
            tagsWrapper.removeChild(item);
            allowedValues = allowedValues.filter(item => item !== value);
            selector.value = '';
          });
          tagsWrapper.appendChild(item);
          allowedValues.push(value);
        }
      }
    });
    defaultNode?.addEventListener('click', () => {
        tagsWrapper.removeChild(defaultNode);
        allowedValues = [];
        selector.value = '';
    });
  };
  init();
}